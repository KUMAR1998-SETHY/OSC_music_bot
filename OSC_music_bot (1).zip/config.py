TOKEN = "your_bot_token_here"
OWNER_ID = 123456789  # Replace with your Telegram user ID
